# Design notes

## Modeling approach

This is an agent-based model, not a single time-series: each player is an
independent agent with its own state (position, stamina, possession) and
decision rule, run on a discrete-time tick loop. "A tactic beats another
tactic" is answered by running many simulated matches (Monte Carlo) and
comparing aggregate outcomes, not by reading one match's score.

Every mechanism in the engine follows the same decomposition discipline:
one shared function computes an action's success probability from ability,
stamina, pressure, and distance (`resolution.success_probability`), rather
than each action type (pass, shot, cross, dribble) having its own
hand-rolled formula. Tackles are the one exception that gets a dedicated
function (`resolution.tackle_success_probability`), because a tackle is a
genuine duel between two players' abilities, not a single actor's roll
against a fixed difficulty.

## Why the ball is a separate agent

Early versions synced the ball's position directly to whichever player
"had" it, with passes resolving instantly. This made mid-flight
interception, through balls into space (rather than at a teammate's
current position), and realistic pass timing impossible to express. The
ball is now its own object (`core.Ball`) with position, velocity, and a
flight state, and passes take real travel time, during which an opponent
can step into the passing lane.

## Tactics are parameter sets, not scripts

A `Tactic` is a formation plus a set of continuous knobs (line height,
width, pressing intensity/trigger distance, tempo, directness, risk
tolerance, shoot eagerness). A named archetype like "possession" or "high
press" is just a specific point in that parameter space — there's no
special-cased code path per named style. `RoleInstruction` extends this to
individual formation slots: any team-wide field can be overridden for one
slot, plus a `leash_radius` field that isn't a team-wide concept at all —
it's a hard cap on how far that slot's target position (and restart
placement) can be from its home formation anchor, regardless of what team
shape or pressing logic would otherwise produce.

## Calibration history (why the constants are what they are)

Several constants in this engine were picked, tested against realistic
baselines, found wrong, and corrected. Recorded here so the next change
doesn't have to rediscover the same failure modes:

- **Shot decision weight.** Early version gave `SHOOT` a weight comparable
  to `PASS` whenever a player was in range (~45% of decisions once in
  range), producing 30-goal matches. Shooting is now gated to a much
  tighter range and a small base weight — being "in range" should rarely
  be the dominant factor in the decision.
- **Goalkeeper save rate.** Initial save probability was too low
  (multiplied by 0.6), contributing to the same inflated scoring. Raised
  to a save multiplier that keeps scorelines in a believable band.
- **Pass execution noise.** Added to make pass completion realistic and to
  give the "ball goes out of bounds → corner" rule something to trigger on.
  First pass at the noise magnitude produced ~80 corners per match (should
  be ~8-12); the standard deviation coefficients were cut by roughly 2x to
  land in a realistic range. Tuned against three seeded matches rather than
  one, since a single seed doesn't distinguish a fixed bug from variance.
- **Tackle frequency.** The original "any defender within 2m attempts a
  tackle" rule produced ~1,900 tackle attempts per match (real matches: 
  20-40). Replaced with geometric gating: a tackle is only attempted when
  it's a standing-tackle distance and the defender hasn't been beaten, or a
  last-man sliding tackle, itself probabilistically gated so it isn't
  attempted every time the situation calls for one.
- **Stamina depletion.** `depletion_rate` was picked to "look like a small
  number" rather than derived from a target. Checking the actual
  arithmetic: a professional player covers ~9,000-12,000m per match, but
  the original constant drained a player's stamina to zero after only
  ~1,000-1,500m — roughly an order of magnitude too aggressive. Flagged as
  needing recalibration against an explicit target (e.g. "a 100-rated
  player should have ~60% stamina left after 10,000m covered"), not yet
  fixed.
- **Tick length (`TICK_SECONDS = 2.0`).** Chosen for computational
  tractability (this is a tactical simulation, not a physics engine) but
  has a real side effect: at typical pass speeds (18-23 m/s), one tick
  covers 37-46m, so a normal 10-20m pass resolves in under half a tick —
  the mid-flight interception check effectively only gets exercised for
  long balls, not routine short passing. Not yet fixed; the two options are
  shrinking the global tick (affects every other tuned constant) or giving
  ball flight its own finer sub-stepping independent of the outer tick
  rate (more targeted, cheaper).

## Known-broken: the counter-attack archetype

Comparing four style variants for a specific squad (see `squads/best_xi.py`)
surfaced a real modeling gap, not just a tuning number. "Low Block Counter"
(`squads/squad_styles.py`) scored **zero goals across 20 matches** with 0.1
shots per match. The cause: `directness` is a constant team-wide weight
applied to every pass decision regardless of game state, so defenders facing
their own goal attempt long, speculative through balls just as often as a
player breaking forward after winning the ball in space. Those passes from
deep, under no space advantage, get intercepted almost immediately. A real
counter-attacking tactic needs directness/tempo to spike only in the window
right after a turnover, then decay back to patient build-up — a
state-dependent trigger, which doesn't exist yet. Until it does, any
simulation result for a low-block or counter-attacking style should be
treated as untrustworthy, not as evidence the approach doesn't suit a given
squad.

## Open items, roughly in priority order

1. State-dependent counter-attack trigger (above) — blocks trusting any
   counter-attacking tactic comparison.
2. Stamina depletion recalibration against an explicit distance-covered target.
3. Ball-flight sub-stepping independent of the main tick rate.
4. Leash should arguably also constrain on-ball dribbling distance, not
   just off-ball positioning — currently a disciplined player can still
   carry the ball forward indefinitely once they have it.
5. Throw-ins and offside (currently: any ball out of play is a corner).
6. Goalkeeper-specific aerial/command mechanic for crosses and corners.
