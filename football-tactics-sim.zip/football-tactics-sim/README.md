# football-tactics-sim

An agent-based football match simulator built to answer one question: given two
tactics — formation, team-wide instructions, and individual per-player
instructions — which one wins more often, and why?

Each player is an independent agent with their own ability ratings, decision
weights, and (optionally) special abilities. The ball is a separate agent
with its own position and flight time, not teleported between players, so
passes can be intercepted mid-flight and through balls can be played into
space rather than at a teammate's feet. Matches run as a discrete-time tick
loop; running many simulated matches (Monte Carlo) turns a single result into
a win-rate comparison between tactics.

This is a tactical/strategic simulation, not a physics engine: positions,
pressure, and ability ratings drive stochastic outcomes rather than modeling
ball physics, player collision, or biomechanics.

## What it models

- **Players** as agents with position, stamina, and per-action ability
  ratings (pace, passing, shooting, dribbling, tackling, crossing, heading,
  vision, strength), plus optional conditional special abilities (e.g. a
  "clinical finisher" bonus only inside the box).
- **The ball** as its own agent: carried (synced to a player's position) or
  in flight (its own trajectory, interceptable by any opponent it passes
  near, capturable by whoever reaches it when it arrives).
- **Tactics** as parameter sets, not scripts: a formation plus team-wide
  shape/pressing/possession knobs, with optional per-role overrides (e.g.
  "this CDM stays back, tight leash, rarely presses") that take precedence
  over the team default for that one slot, including at restarts.
- **Defending** as a geometric decision, not a proximity trigger: a tackle is
  only attempted when it's sensible (standing vs. sliding tackle range,
  whether the defender has already been beaten, whether they're the last
  man), and is resolved as a duel between the defender's and attacker's
  relevant abilities.
- **Restarts**: kickoffs, goal kicks (with a keeper short/long decision),
  and a simplified "any ball out of play becomes a corner" rule. Throw-ins,
  free-kick routines, and offside are explicitly not modeled yet (see
  Known limitations).
- **Monte Carlo evaluation**: run the same matchup many times with different
  random seeds, aggregate win rate, goal difference, and per-category stats
  (passing, shooting, tackling) to compare tactics with actual confidence
  rather than a single match's noise.

## Project layout

```
football-tactics-sim/
├── footysim/              # the simulation engine (reusable, has no knowledge of any specific squad)
│   ├── core.py            # Player, Team, Ball, Abilities, TeamStats, enums
│   ├── tactics.py         # Tactic, RoleInstruction, formations, shape geometry, leash logic
│   ├── resolution.py      # success-probability and tackle-duel math
│   ├── match_engine.py    # Match: the tick-by-tick simulation loop
│   └── team_builder.py    # random squad generation + example special-ability presets
├── squads/                 # concrete squad definitions (depends on footysim, not the reverse)
│   ├── best_xi.py          # a specific scouted 11, with selection reasoning in the docstring
│   └── squad_styles.py     # tactical style variants for that squad
├── scripts/                 # runnable entry points
│   ├── run_single_match.py           # one match, box score + event log
│   ├── run_role_instruction_demo.py  # proves a per-role leash override actually holds
│   └── run_style_comparison.py       # Monte Carlo tournament across style variants
├── results/                 # generated output (JSON match batches)
├── tests/                   # unit tests (placeholder — current scripts are smoke tests, not pytest)
├── docs/
│   └── design_notes.md      # the modeling framework behind this project, calibration log, known gaps
├── requirements.txt
└── README.md
```

`footysim/` has no knowledge of any specific players — it's the engine.
`squads/` is where a real roster lives, built from `footysim`'s primitives.
This split is deliberate: a different squad or a different sport-specific
ruleset should never require touching the engine.

## Running it

```bash
pip install -r requirements.txt

# run as modules from the repo root, so footysim/ and squads/ resolve as packages
python3 -m scripts.run_single_match
python3 -m scripts.run_role_instruction_demo
python3 -m scripts.run_style_comparison        # takes a few minutes — runs dozens of full matches
```

## Known limitations

These are tracked honestly rather than glossed over, since they materially
affect which simulation results can be trusted:

- **No throw-ins, free-kick routines, or offside.** Any ball leaving the
  pitch restarts as a corner for whichever team had it last — a deliberate
  simplification, not an oversight.
- **Goalkeeper aerial command / set-piece organizing isn't modeled.**
  Corners resolve generically against the defending team's outfield
  pressure; a keeper's height, command of the box, or wall-organizing
  ability has no dedicated mechanic yet.
- **`directness` is a constant weight, not state-dependent.** A counter-attacking
  tactic (low block, soak pressure, break fast once the ball is won) isn't
  properly expressible yet — the engine applies the same pass-directness
  weight regardless of whether the team just won the ball in space or is
  patiently building out of their own third. This produces unrealistic
  results for any "counter" style as currently configured (see
  `docs/design_notes.md` for the specific evidence). The fix is a real
  piece of work: a possession-change trigger that temporarily spikes
  directness/tempo right after a turnover, then decays.
- **Dribbling isn't leash-constrained.** A disciplined player's leash caps
  their off-ball positioning and restart placement, but once they're
  carrying the ball themselves, dribbling forward is unconstrained.
- **No cards, injuries, or fatigue-driven substitutions.**

See `docs/design_notes.md` for the full reasoning behind the architecture,
the calibration numbers that justified specific constants, and a more
complete list of what's been surfaced as broken-and-fixed vs.
broken-and-still-open.
